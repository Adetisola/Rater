"use client";

// AnimatedScribble - Calm, looping hand-drawn stroke animation
// Uses stroke-dasharray/dashoffset for draw/erase cycle
// Cycle: draw (2s) → hold (3s) → erase (2s) → pause (4s) → repeat

import { useEffect, useRef, useState } from 'react';

interface AnimatedScribbleProps {
  className?: string;
}

export function AnimatedScribble({ className }: AnimatedScribbleProps) {
  const pathRef = useRef<SVGPathElement>(null);
  const [pathLength, setPathLength] = useState(0);

  useEffect(() => {
    if (pathRef.current) {
      setPathLength(pathRef.current.getTotalLength());
    }
  }, []);

  // Total cycle: 11s
  // 0-2s: draw in (ease-in-out)
  // 2-5s: hold fully drawn
  // 5-7s: erase out (ease-in-out)
  // 7-11s: pause (invisible), then repeat

  // Convert timing to percentages of 11s total
  // draw:  0% → 18.2%  (2/11)
  // hold:  18.2% → 45.5%  (3/11)
  // erase: 45.5% → 63.6%  (2/11)
  // pause: 63.6% → 100%  (4/11)

  const animationStyle = pathLength > 0 ? {
    strokeDasharray: pathLength,
    strokeDashoffset: -pathLength, // start hidden (from left side)
    animation: 'scribbleDraw 11s cubic-bezier(0.4, 0, 0.2, 1) infinite',
  } : {
    opacity: 0,
  };

  return (
    <>
      <style>{`
        @keyframes scribbleDraw {
          0% {
            stroke-dashoffset: ${-pathLength};
            opacity: 1;
          }
          18.2% {
            stroke-dashoffset: 0;
            opacity: 1;
          }
          45.5% {
            stroke-dashoffset: 0;
            opacity: 1;
          }
          63.6% {
            stroke-dashoffset: ${pathLength};
            opacity: 1;
          }
          63.7% {
            stroke-dashoffset: ${-pathLength};
            opacity: 0;
          }
          90% {
            stroke-dashoffset: ${-pathLength};
            opacity: 0;
          }
          100% {
            stroke-dashoffset: ${-pathLength};
            opacity: 0;
          }
        }
      `}</style>
      <svg 
        width="205" 
        height="58" 
        viewBox="0 0 205 58" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        aria-hidden="true"
      >
        <path 
          ref={pathRef}
          d="M200.276 21.8555C195.422 18.7415 191.743 16.7354 187.307 14.6924C182.796 12.6151 177.774 10.6142 174.33 9.63867C173.774 9.48125 173.316 9.36922 172.938 9.29297C172.943 9.3277 172.947 9.3637 172.952 9.40039C173.192 11.138 174.015 13.8797 175.082 17.2188C176.105 20.4219 177.312 24.0574 178.118 27.2256C178.518 28.7959 178.867 30.4212 178.962 31.9287C179.055 33.4006 178.934 35.1533 178.01 36.6973C176.998 38.3871 175.343 39.3137 173.442 39.6553C171.65 39.9775 169.517 39.8132 167.09 39.3203C164.489 38.7921 161.13 37.4843 157.76 36.0762C154.246 34.6081 150.678 33.012 147.199 31.624C143.713 30.2332 140.724 29.2252 138.567 28.9072C137.71 28.7808 137.175 28.7947 136.881 28.8379C135.629 32.897 135.67 37.7143 135.532 42.2168C135.467 44.3516 135.354 46.6272 134.852 48.4121C134.594 49.3251 134.165 50.3828 133.361 51.2578C132.475 52.2234 131.282 52.7994 129.911 52.8662C127.759 52.9709 125.316 52.3864 122 51.0527C118.656 49.7078 114.138 47.4789 107.743 44.0078C94.9384 37.0572 74.8365 25.2715 60.4863 16.1553C53.4266 11.6705 47.9252 7.59228 43.6924 4.5C43.7353 4.56919 43.7791 4.63818 43.8223 4.70801C48.2947 11.9479 54.0933 22.6949 57.3291 35.9688C57.8491 38.1021 57.9501 40.281 57.0254 42.1191C55.9965 44.1639 54.0992 45.0448 52.2979 45.2627C50.5977 45.4683 48.7672 45.1367 47.0762 44.6201C45.3401 44.0898 43.5174 43.2918 41.7451 42.3496C34.7178 38.6136 28.4673 34.8666 23.7998 32.2939C21.3976 30.9699 19.3755 29.9314 17.6943 29.2285C15.9947 28.518 14.9241 28.2749 14.3125 28.2646C14.2534 28.2835 14.0461 28.3622 13.667 28.6475C13.0846 29.0858 12.3289 29.8398 11.3896 31.0156C9.5131 33.3648 7.25521 36.9439 4.50098 41.7646"
          stroke="#FEC312" 
          strokeWidth="8" 
          strokeLinecap="round" 
          strokeLinejoin="round"
          style={animationStyle}
        />
      </svg>
    </>
  );
}
